$(function(){
	$(".imageA").click(function(){
		$(this).addClass("element-animation");
	});	
});
