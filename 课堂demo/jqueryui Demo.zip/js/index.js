$(function(){
	$("#login").dialog({
		width:600,
		height:300,
		autoOpen:false,
		modal:true,
		show:{
			effect:"blind",
			duration:1000
		},
		hide:{
			effect:"explode",
			duration:1000
		}
	});
	

	$("#loginA").click(function(){
		//$("#login").dialog("open");
		$("#themeLink").attr("href","css/green/jquery-ui.css");
	});

	$("#txtBirth").datepicker();

	$( "#qqChat" ).draggable({ handle: "#chatTitle",containment:"#???" });
	$("#photoArea .photos").each(function(i){
		$(this).html(i);
	});
	$("#photoArea").sortable();

	$("#myMenu").menu();
});